.. mdinclude:: ../../../Scripts/sln_alexa_iot_secure_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   manf
   oem
