prog_sec_app
=====================

.. automodule:: Scripts.sln_alexa_iot_secure_boot.manf.prog_sec_app
    :members: main

.. autofunction:: Scripts.sln_alexa_iot_secure_boot.manf.prog_sec_app.cert_cb

.. autofunction:: Scripts.sln_alexa_iot_secure_boot.manf.prog_sec_app.pkey_cb
