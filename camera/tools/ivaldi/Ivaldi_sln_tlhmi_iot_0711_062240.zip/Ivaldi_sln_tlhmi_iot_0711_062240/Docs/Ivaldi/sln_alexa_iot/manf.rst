.. mdinclude:: ../../../Scripts/sln_alexa_iot_secure_boot/manf/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   prog_sec_app
   enable_hab
