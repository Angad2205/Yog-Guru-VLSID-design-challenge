.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_local2_rd_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   local2_rd_board_config
