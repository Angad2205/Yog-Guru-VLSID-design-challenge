.. automodule:: Scripts.sln_platforms_config.sln_svui_iot_config.board_config
    :members:
