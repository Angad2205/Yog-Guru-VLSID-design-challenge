.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_alexa_iot_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   alexa_board_config
