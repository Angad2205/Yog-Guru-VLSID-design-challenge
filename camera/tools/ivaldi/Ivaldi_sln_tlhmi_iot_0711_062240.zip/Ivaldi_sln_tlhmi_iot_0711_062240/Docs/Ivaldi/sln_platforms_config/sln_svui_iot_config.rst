.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_svui_iot_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   svui_board_config
