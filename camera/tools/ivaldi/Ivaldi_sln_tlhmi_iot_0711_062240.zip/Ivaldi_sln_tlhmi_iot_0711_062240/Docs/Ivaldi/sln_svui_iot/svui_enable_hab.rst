enable_hab
==========

.. automodule:: Scripts.sln_svui_iot_secure_boot.manf.enable_hab
    :members: main
