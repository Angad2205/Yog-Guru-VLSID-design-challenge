.. mdinclude:: ../../../Scripts/sln_svui_iot_secure_boot/oem/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   svui_setup_hab
   svui_secure_app
