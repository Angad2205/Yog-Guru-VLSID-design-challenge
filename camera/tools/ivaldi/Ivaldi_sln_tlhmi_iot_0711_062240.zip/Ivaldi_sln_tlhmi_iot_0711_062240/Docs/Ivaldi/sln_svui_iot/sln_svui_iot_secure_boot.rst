.. mdinclude:: ../../../Scripts/sln_svui_iot_secure_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   svui_manf
   svui_oem
