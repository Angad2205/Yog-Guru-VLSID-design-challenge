open_prog_full
==============

.. automodule:: Scripts.sln_svui_iot_open_boot.open_prog_full
    :members: main
