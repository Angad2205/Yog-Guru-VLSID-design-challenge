.. mdinclude:: ../../../Scripts/sln_vizn3d_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   vizn3d_open_prog_full
