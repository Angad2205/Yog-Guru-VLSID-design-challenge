.. mdinclude:: ../../../Scripts/sln_vizn_iot_secure_boot/oem/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   vizn_setup_hab
