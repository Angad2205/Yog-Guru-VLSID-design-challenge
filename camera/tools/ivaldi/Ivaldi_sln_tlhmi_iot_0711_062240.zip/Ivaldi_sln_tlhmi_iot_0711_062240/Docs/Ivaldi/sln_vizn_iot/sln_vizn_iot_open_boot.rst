.. mdinclude:: ../../../Scripts/sln_vizn_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   sln_vizn_iot_open_boot_src
