Scripts
=======

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   demos/demos
   ota_signing
   ffs_provision/ffs_provision_folder
   sln_iot_utils
   sln_alexa_iot/sln_alexa_iot_master
   sln_local2_iot/sln_local2_iot_master
   sln_vizn_iot/sln_vizn_iot_master
   sln_viznas_iot/sln_viznas_iot_master
   sln_vizn3d_iot/sln_vizn3d_iot_master
   sln_svui_iot/sln_svui_iot_master
   sln_platforms_config/sln_platforms_config