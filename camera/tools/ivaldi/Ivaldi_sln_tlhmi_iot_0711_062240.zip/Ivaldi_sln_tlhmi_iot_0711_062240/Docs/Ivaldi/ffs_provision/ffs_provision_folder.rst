.. mdinclude:: ../../../Scripts/ffs_provision/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   ffs_provision
   gen_prov_json
   dha_cert_gen
   provision
