.. mdinclude:: ../../Scripts/sln_iot_utils/README.md
