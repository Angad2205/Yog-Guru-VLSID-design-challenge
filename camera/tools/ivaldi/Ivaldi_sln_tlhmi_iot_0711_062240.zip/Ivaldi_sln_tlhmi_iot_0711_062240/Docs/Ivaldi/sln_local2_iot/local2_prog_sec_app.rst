prog_sec_app
============

.. automodule:: Scripts.sln_local2_iot_secure_boot.manf.prog_sec_app
    :members: main
