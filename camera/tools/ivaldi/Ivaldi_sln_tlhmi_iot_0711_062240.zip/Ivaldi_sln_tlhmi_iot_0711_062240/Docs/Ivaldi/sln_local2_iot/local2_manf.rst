.. mdinclude:: ../../../Scripts/sln_local2_iot_secure_boot/manf/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   local2_prog_sec_app
   local2_enable_hab
