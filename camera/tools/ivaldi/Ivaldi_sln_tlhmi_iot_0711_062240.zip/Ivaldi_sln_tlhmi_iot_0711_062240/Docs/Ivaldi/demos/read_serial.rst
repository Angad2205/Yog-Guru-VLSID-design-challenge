read_serial
===========

.. automodule:: Scripts.demos.read_serial
    :members: main
