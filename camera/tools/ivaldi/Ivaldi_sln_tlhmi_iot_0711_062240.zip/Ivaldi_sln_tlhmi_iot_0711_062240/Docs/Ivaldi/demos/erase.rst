erase
=====

.. automodule:: Scripts.demos.erase
    :members: main
