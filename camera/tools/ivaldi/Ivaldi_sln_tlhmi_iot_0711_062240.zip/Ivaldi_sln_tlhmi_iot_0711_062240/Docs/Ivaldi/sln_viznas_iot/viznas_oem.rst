.. mdinclude:: ../../../Scripts/sln_viznas_iot_secure_boot/oem/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   viznas_setup_hab
