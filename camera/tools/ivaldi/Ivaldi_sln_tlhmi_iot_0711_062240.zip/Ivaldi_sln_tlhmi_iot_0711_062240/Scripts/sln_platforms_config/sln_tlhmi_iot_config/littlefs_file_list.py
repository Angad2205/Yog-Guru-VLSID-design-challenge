#!/usr/bin/env python3

"""

Copyright 2022-2023 NXP.

NXP Confidential. This software is owned or controlled by NXP and may only be used strictly in accordance
with the license terms that accompany it. By expressly accepting such terms or by downloading, installing,
activating and/or otherwise using the software, you are agreeing that you have read, and that you
agree to comply with and are bound by, such license terms. If you do not agree to be bound by the
applicable license terms, then you may not retain, install, activate or otherwise use the software.

File
++++
/Scripts/littlefs/littlefs_file_list.py

Brief
+++++
** Defines a dictionary that contains files to be added in the filesystem, key
dictionary [(FilePath, LittlefsFilePath, encrypted)]
**

.. versionadded:: 0.0

"""
# Note. Current version of littlefs-python does not support adding attribute. Encrypt is not being used

PEM_CERTIFICATE_PATH = "../sln_tlhmi_iot_open_boot/aws_crt.pem"
PEM_PRIVATE_KEY_PATH = "../sln_tlhmi_iot_open_boot/aws_prv.pem"

# List with the files that needs to be written in the prebuilt filesystem
fileList_IVD_AWS = [
    ("../ota_signing/ca/certs/prod.root.ca.crt.pem", "ca_root.dat", False),
    ("../ota_signing/ca/certs/prod.app.a.crt.pem", "app_a_sign_cert.dat", False),
    (PEM_PRIVATE_KEY_PATH, "pkey.dat", False),
    (PEM_CERTIFICATE_PATH, "cert.dat", False),
]

fileList_IVD = [
    ("../ota_signing/ca/certs/prod.root.ca.crt.pem", "ca_root.dat", False),
    ("../ota_signing/ca/certs/prod.app.a.crt.pem", "app_a_sign_cert.dat", False),
]

fileList_AWS = [
    (PEM_PRIVATE_KEY_PATH, "pkey.dat", False),
    (PEM_CERTIFICATE_PATH, "cert.dat", False),
]

fileList_Littlefs = [
]

fileList_EMPTY = [
]

def getFilesListName(imageVerificationDisabled, AwsDisabled):
    configStr = ""

    print (str(imageVerificationDisabled) +' '+ str(AwsDisabled))
    if imageVerificationDisabled == True and AwsDisabled == True:
        configStr = "fileList_EMPTY"
    if imageVerificationDisabled == True and AwsDisabled == False:
        configStr = "fileList_AWS"
    if imageVerificationDisabled == False and AwsDisabled == True:
        configStr = "fileList_IVD"
    if imageVerificationDisabled == False and AwsDisabled == False:
        configStr = "fileList_IVD_AWS"

    return configStr

